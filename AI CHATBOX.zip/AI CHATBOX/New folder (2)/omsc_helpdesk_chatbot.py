import re
from typing import Optional

INTENT_PATTERNS = {
    'admissions': [r'\badmission', r'\bapply\b', r'\bapplication\b', r'\bdeadline'],
    'curriculum': [r'\bcurriculum\b', r'\bcourses?\b', r'\bsubjects?\b', r'\bsyllabus\b', r'\brequirements?\b'],
    'fees': [r'\bfee(s)?\b', r'\btuition\b', r'\bfinancial aid\b', r'\bscholarship(s)?\b', r'\bcost\b'],
    'technical_support': [r'\btech(nical)? support\b', r'\bportal\b', r'\blogin\b', r'\bissues?\b', r'\bhelpdesk\b'],
    'advising': [r'\badvis(ing|or)\b', r'\bguidance\b', r'\bcourse planning\b'],
    'schedule': [r'\bschedule\b', r'\bcalendar\b', r'\bsemester\b', r'\boffice hours\b'],
    'contact': [r'\bcontact\b', r'\bemail\b', r'\bphone\b'],
    'program_length': [r'\bduration\b', r'\blength\b', r'\bhow long\b', r'\btime\b'],
    'graduation': [r'\bgraduat(e|ion)\b', r'\bcredit(s)?\b', r'\bcapstone\b'],
    'resources': [r'\bresource(s)?\b', r'\blibrary\b', r'\blms\b', r'\bcanvas\b', r'\bfaq\b'],
    'help': [r'\bhelp\b', r'\bmenu\b', r'\boptions\b']
}

RESPONSES = {
    'admissions': "OMSC admissions: submit online application, transcripts, CV, statement of purpose, and 2–3 references. Deadlines: Fall 31 Mar, Spring 30 Sep. Check the admissions portal for exact dates.",
    'curriculum': "Curriculum: core CS foundations plus electives in AI, systems, theory, and data. Typical load: 2 courses per term; total 10 courses with at least 3 cores.",
    'fees': "Fees: tuition billed per credit. Financial aid includes scholarships, employer tuition assistance, and limited teaching support. See the fees page for current rates.",
    'technical_support': "Technical support: for login/portal issues, open a ticket at IT Helpdesk. Include your student ID and screenshots. Live chat 9:00–17:00 local time.",
    'advising': "Academic advising: book appointments via the advising portal for course planning and degree progress reviews.",
    'schedule': "Schedule: semesters start Jan and Aug; office hours vary by instructor. See the academic calendar for add/drop and exam dates.",
    'contact': "Contact: omsc@university.edu, +1 (555) 123‑4567. Response within 1–2 business days.",
    'program_length': "Program length: most students finish in 24–36 months part‑time. Pace is flexible.",
    'graduation': "Graduation: complete required credits, maintain GPA ≥ 3.0, and satisfy capstone/project requirements.",
    'resources': "Student resources: LMS (Canvas), library e‑resources, career services, and FAQs. Access via the student portal.",
    'help': "I can help with: admissions, curriculum, fees, technical support, advising, schedule, contact, program length, graduation, resources. Ask a question or type 'exit'.",
    'fallback': "I didn't catch that. Type 'help' to see topics or rephrase your question."
}

COMPILED = {k: [re.compile(p, re.I) for p in v] for k, v in INTENT_PATTERNS.items()}

def detect_intent(text: str) -> Optional[str]:
    t = text.strip()
    if not t:
        return 'help'
    for intent, patterns in COMPILED.items():
        for pattern in patterns:
            if pattern.search(t):
                return intent
    return None

def respond(text: str) -> str:
    intent = detect_intent(text)
    if intent is None:
        return RESPONSES['fallback']
    return RESPONSES[intent]

def chat():
    print("OMSC Helpdesk Chatbot. Type 'help' for options, 'exit' to quit.")
    while True:
        user = input("> ")
        if not user:
            print(RESPONSES['fallback'])
            continue
        if re.search(r'\b(exit|quit|bye)\b', user, re.I):
            print("Goodbye.")
            break
        print(respond(user))

if __name__ == '__main__':
    chat()
