def get_response(user_input):
    raw = (user_input or "").strip()
    text = raw.lower()
    if not text:
        return "What can I help you with today?"
    lang = "en"

    if any(k in text for k in ["bye", "paalam"]):
        return "Thanks! If you have more questions, just come back."
    if any(k in text for k in ["hello", "hi", "hey", "kamusta", "kumusta"]):
        return "Hello! I'm the Student Helpdesk Chatbot. How can I help you today?"
    if any(k in text for k in ["name", "pangalan", "who are you"]):
        return "I'm the Student Helpdesk chatbot that answers student questions."
    if any(k in text for k in ["help", "tulong", "assist", "tanong"]):
        return "You can ask about enrollment, schedules, tuition/fees, scholarships, transcripts, student ID, and office hours."

    intents = [
        ("enrollment", ["enroll", "enrollment", "enrolment", "mag-enroll", "paano ang enrollment", "enrol"]),
        ("requirements", ["requirements", "requirement", "docs", "documents", "requirements sa enrollment", "kailangan"]),
        ("schedule", ["schedule", "class schedule", "oras ng klase", "timetable", "sectioning"]),
        ("tuition", ["tuition", "tuition fee", "bayad", "fees", "tuition and fees", "magkano"]),
        ("payment", ["payment", "bayad", "installment", "gcash", "online payment", "cashier"]),
        ("scholarship", ["scholar", "scholarship", "discount", "grant", "financial aid"]),
        ("registrar", ["registrar", "transcript", "tor", "certificate", "cor", "grades", "honorable dismissal"]),
        ("id", ["id", "school id", "lost id", "replace id", "student id"]),
        ("library", ["library", "aklatan", "lib hours", "borrow", "return"]),
        ("guidance", ["guidance", "counsel", "counseling", "psych", "student affairs"]),
        ("it", ["it", "helpdesk", "portal", "password", "reset", "email", "wifi"]),
        ("deadlines", ["deadline", "last day", "cutoff", "enrollment deadline", "payment deadline"]),
        ("hours", ["open", "hours", "office hours", "time open", "closing"]),
        ("contact", ["contact", "email", "phone", "hotline", "address", "location", "where"]),
    ]

    def has(keys):
        return any(k in text for k in keys)

    if has(["paano", "how"]) and has(["enroll", "enrollment", "enrol"]):
        intent = "enrollment"
    else:
        intent = next((i for i, keys in intents if has(keys)), None)

    responses = {
        "enrollment": "To enroll: 1) Clear accounts and requirements; 2) Log in to the student portal for sectioning and subject selection; 3) Review your COR; 4) Pay assessed fees; 5) Upload the receipt if required.",
        "requirements": "Common requirements: valid ID, previous COR/grades, admission documents, and clearance. For transferees, TOR and honorable dismissal are typically required.",
        "schedule": "View your class schedule in the student portal under 'My Classes' or 'COR'. Check updates as rooms and times can change.",
        "tuition": "Tuition and other fees depend on units and laboratory classes. See the breakdown on the assessment page after subject selection.",
        "payment": "Payment options: on-campus cashier, bank deposit, online transfer (e.g., GCash/bank apps), and installment depending on policy. Upload proof of payment in the portal.",
        "scholarship": "For scholarships and discounts, apply through Student Affairs or the Scholarship Office. There are usually grade requirements and submission deadlines.",
        "registrar": "Registrar services: TOR, certificate of enrollment, COR reprint, and verification. Request online and wait for an email notification when ready for pickup or for a digital copy.",
        "id": "For lost or replacement Student ID, file a report, bring a valid ID, and pay the replacement fee at the cashier.",
        "library": "Library hours are typically 8:00–17:00 on weekdays. Use your library account to borrow; avoid penalties for late returns.",
        "guidance": "For counseling or student support, visit the Guidance/Student Affairs office. You may also book an appointment online if available.",
        "it": "For portal issues, password reset, or email problems, contact the IT Helpdesk. Prepare your student ID number and an error screenshot.",
        "deadlines": "Important deadlines (enrollment, add/drop, payment) are posted in the academic calendar and portal announcements.",
        "hours": "Office hours for key services: Registrar and Cashier are usually 8:00–17:00 on weekdays; processing may cut off one hour before closing.",
        "contact": "Contacts: Registrar, Cashier, Student Affairs, IT Helpdesk. Visit the campus website for email, hotline, and address.",
    }

    if intent in responses:
        return responses[intent]

    if any(k in text for k in ["fees", "bayarin", "magkano", "amount"]):
        return "Fees depend on units, lab fees, and miscellaneous charges. Check the assessment in the portal for the exact amount."
    if any(k in text for k in ["drop", "add", "change subject", "shift", "dagdag", "bawas"]):
        return "For add/drop of subjects, file the request in the portal within the add/drop period and follow your department's approval flow."

    return "No exact match found. Try: enrollment, schedule, tuition/fees, payment, scholarship, registrar, ID, library, guidance, IT, deadlines, office hours, contacts."

def chat():
    print("Student Helpdesk Chatbot (type 'bye' to exit)")
    while True:
        user_input = input("You: ")
        reply = get_response(user_input)
        print("Bot:", reply)
        if (user_input or "").lower().strip() in ["bye", "paalam"]:
            break

if __name__ == "__main__":
    chat()
